Frozen candidate model data, not standalone runtime. Use the repository Snakefile-r4 to reproduce. Effective CP/EP replacement costs, not pure FCT. 1F1B only; startup/optimizer tail not recalibrated.
